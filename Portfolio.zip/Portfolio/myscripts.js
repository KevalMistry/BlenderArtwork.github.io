document.addEventListener("DOMContentLoaded", function () {
  var navLinks = document.querySelectorAll(".options a");

  for (var i = 0; i < navLinks.length; i++) {
    navLinks[i].addEventListener("click", function (event) {
      event.preventDefault();
      var target = document.querySelector(this.getAttribute("href"));

      if (target) {
        var targetOffsetTop = target.offsetTop;
        var windowHeight = window.innerHeight;
        var navbarHeight = document.querySelector(".Nav").offsetHeight;
        var scrollPosition = targetOffsetTop - navbarHeight;

        if (scrollPosition > windowHeight) {
          scrollPosition -= windowHeight / 2;
        }

        window.scrollTo({
          top: scrollPosition,
          behavior: "smooth",
        });
      }
    });
  }
});

function blinkIcons(iconIndexes) {
  var navIcons = document.getElementsByClassName("nav-icon");

  // Remove blinking class from all icons
  for (var i = 0; i < navIcons.length; i++) {
    navIcons[i].classList.remove("blinking-icon");
  }

  // Blink icons in sequential order
  var delay = 0;
  for (var j = 0; j < iconIndexes.length; j++) {
    var iconIndex = iconIndexes[j];
    var targetIcon = document.getElementById("icon-" + iconIndex);

    setTimeout(
      (function (icon) {
        return function () {
          icon.classList.add("blinking-icon");
          setTimeout(function () {
            icon.classList.remove("blinking-icon");
          }, 1000);
        };
      })(targetIcon),
      delay
    );

    delay += 1000; // Delay next icon by 1 second
  }
}
